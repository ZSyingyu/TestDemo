//
//  ViewController.m
//  TableViewLinkageDemo
//
//  Created by liguo.chen on 16/9/28.
//  Copyright © 2016年 Slience. All rights reserved.
//

#import "ViewController.h"
#import "ZYYTableViewLinkageViewController.h"

//屏幕宽
#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)
//屏幕高
#define SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"仿美团外卖tableview联动";
    self.navigationController.navigationBar.barTintColor = [UIColor purpleColor];
    self.navigationController.navigationBar.translucent = NO;
    [self.navigationController.navigationBar setTitleTextAttributes:
     @{NSFontAttributeName:[UIFont systemFontOfSize:19],
       NSForegroundColorAttributeName:[UIColor redColor]}];
    
    UIButton *webBtn1 = [[UIButton alloc] initWithFrame:CGRectMake(10, 100, SCREEN_WIDTH - 20, 50)];
    webBtn1.backgroundColor = [UIColor purpleColor];
    [webBtn1 setTitle:@"仿美团外卖tableview联动" forState:UIControlStateNormal];
    [webBtn1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [webBtn1 addTarget:self action:@selector(webAction1) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:webBtn1];
}

-(void)webAction1 {
    ZYYTableViewLinkageViewController *linkVc = [[ZYYTableViewLinkageViewController alloc] init];
//    UINavigationController *linkNavi = [[UINavigationController alloc] initWithRootViewController:linkVc];
//    [self presentViewController:linkVc animated:YES completion:nil];
    [self.navigationController pushViewController:linkVc animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
