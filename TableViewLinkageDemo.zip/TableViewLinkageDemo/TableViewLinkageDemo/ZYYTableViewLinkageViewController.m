//
//  ZYYTableViewLinkageViewController.m
//  ReorganizeFramework
//
//  Created by liguo.chen on 16/9/5.
//  Copyright © 2016年 Slience. All rights reserved.
//

#import "ZYYTableViewLinkageViewController.h"

//屏幕宽
#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)
//屏幕高
#define SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)

#define leftTableViewCell       @"leftTableViewCell"
#define rightTableViewCell      @"rightTableViewCell"

@interface ZYYTableViewLinkageViewController ()<UITableViewDelegate,UITableViewDataSource>

@property(strong,nonatomic)UITableView *leftTableView;
@property(strong,nonatomic)UITableView *rightTableView;

@end

@implementation ZYYTableViewLinkageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"TableView联动";
    [self setBackBarButtonItemWithTitle:@"返回"];
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self.view addSubview:self.leftTableView];
    [self.view addSubview:self.rightTableView];
    
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(CGRectGetMaxX(self.leftTableView.frame), 0, 1, SCREEN_HEIGHT)];
    line.backgroundColor = [UIColor redColor];
    [self.view addSubview:line];
    
}

/**
 *  tableviewDatasource
 */

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (tableView == self.leftTableView) {
        return 1;
    }else {
        return 50;
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (tableView == self.leftTableView) {
        return 50;
    }else {
        return 10;
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (tableView == self.leftTableView) {
        cell = [tableView dequeueReusableCellWithIdentifier:leftTableViewCell forIndexPath:indexPath];
        cell.textLabel.text = [NSString stringWithFormat:@"%ld组",indexPath.row];
    }else {
        cell = [tableView dequeueReusableCellWithIdentifier:rightTableViewCell forIndexPath:indexPath];
        cell.textLabel.text = [NSString stringWithFormat:@"第%ld组--第%ld行",indexPath.section,indexPath.row];
    }
    
    return cell;
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (tableView == self.rightTableView) {
        return [NSString stringWithFormat:@"第%ld组",section];
    }
    return nil;
}

/**
 *  tableviewDelegate
 */

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (tableView == self.leftTableView) {//点击左侧的tableview,右边的tableview跟着滑动到相应位置
        NSIndexPath *moveToIndexPath = [NSIndexPath indexPathForRow:0 inSection:indexPath.row];
        
//        [self.rightTableView selectRowAtIndexPath:moveToIndexPath animated:YES scrollPosition:UITableViewScrollPositionTop];
        
        [self.rightTableView scrollToRowAtIndexPath:moveToIndexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
    }
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == self.leftTableView) return;
    //取出出现在右边tableview上的最上方的cell的indexPath
    
    NSIndexPath *topIndexPath = [[self.rightTableView indexPathsForVisibleRows] firstObject];
    
    //计算左侧tableview移动的indexPath
    
    NSIndexPath *moveToIndexPath = [NSIndexPath indexPathForRow:topIndexPath.section inSection:0];
    
    [self.leftTableView selectRowAtIndexPath:moveToIndexPath animated:NO scrollPosition:UITableViewScrollPositionMiddle];
}

/**
 *  懒加载tableview
 */
-(UITableView *)leftTableView {
    if (!_leftTableView) {
        _leftTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH * 0.3, SCREEN_HEIGHT)];
        _leftTableView.backgroundColor = [UIColor whiteColor];
        _leftTableView.delegate = self;
        _leftTableView.dataSource = self;
        _leftTableView.tableFooterView = [[UIView alloc] init];
        _leftTableView.contentInset = UIEdgeInsetsMake(0, 0, 120, 0);
        [_leftTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:leftTableViewCell];
        [self.view addSubview:_leftTableView];
    }
    return _leftTableView;
}

-(UITableView *)rightTableView {
    if (!_rightTableView) {
        _rightTableView = [[UITableView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH * 0.3, 0, SCREEN_WIDTH * 0.7, SCREEN_HEIGHT)];
        _rightTableView.backgroundColor = [UIColor cyanColor];
        _rightTableView.delegate = self;
        _rightTableView.dataSource = self;
        _rightTableView.tableFooterView = [[UIView alloc] init];
        _rightTableView.contentInset = UIEdgeInsetsMake(0, 0, 120, 0);
        [_rightTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:rightTableViewCell];
        [self.view addSubview:_rightTableView];
    }
    return _rightTableView;
}

//将tableview的分割线顶到两端
-(void)viewDidLayoutSubviews
{
    if ([self.leftTableView respondsToSelector:@selector(setSeparatorInset:)]) {
        [self.leftTableView setSeparatorInset:UIEdgeInsetsMake(0,0,0,0)];
    }
    if ([self.leftTableView respondsToSelector:@selector(setLayoutMargins:)]) {
        [self.leftTableView setLayoutMargins:UIEdgeInsetsMake(0,0,0,0)];
    }
    
    if ([self.rightTableView respondsToSelector:@selector(setSeparatorInset:)]) {
        [self.rightTableView setSeparatorInset:UIEdgeInsetsMake(0,0,0,0)];
    }
    if ([self.rightTableView respondsToSelector:@selector(setLayoutMargins:)]) {
        [self.rightTableView setLayoutMargins:UIEdgeInsetsMake(0,0,0,0)];
    }
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}

/**
 *  设置返回按钮标题
 */
- (void)setBackBarButtonItemWithTitle:(NSString *)title
{
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 60, 30)];
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setBackgroundColor:[UIColor clearColor]];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:@"返回"] forState:UIControlStateNormal];
    [btn setContentMode:UIViewContentModeScaleAspectFill];
    [btn setImageEdgeInsets:UIEdgeInsetsMake(0, -7, 0, 50)];
    [btn setTitleEdgeInsets:UIEdgeInsetsMake(0, -5, 0, 10)];
    [btn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *barButtonItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.leftBarButtonItem = barButtonItem;
}

/**
 *  返回按钮点击事件
 */
- (void)backAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
