//
//  ZYYTableViewLinkageViewController.h
//  ReorganizeFramework
//
//  Created by liguo.chen on 16/9/5.
//  Copyright © 2016年 Slience. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZYYTableViewLinkageViewController : UIViewController

@end
